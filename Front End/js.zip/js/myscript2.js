$(document).ready(function(){

var $title = $(".title");
var $face = $(".faces");


});